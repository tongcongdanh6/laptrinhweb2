<?php
$dataAds = [
    [
        "title" => "Coca-Cola",
        "url" => "https://www.cocacolavietnam.com/",
        "thumbnail_url" => "images/ads/cocacola.jpg"
    ],
    [
        "title" => "Facebook",
        "url" => "https://www.facebook.com",
        "thumbnail_url" => "images/ads/facebook.png"
    ],
    [
        "title" => "Apple",
        "url" => "https://www.apple.com",
        "thumbnail_url" => "images/ads/apple.jpg"
    ],
    [
        "title" => "Google",
        "url" => "https://www.google.com",
        "thumbnail_url" => "images/ads/google.png"
    ],
    [
        "title" => "Microsoft",
        "url" => "https://www.microsoft.com",
        "thumbnail_url" => "images/ads/microsoft.png"
    ],
    [
        "title" => "Toyota",
        "url" => "https://www.toyota.com",
        "thumbnail_url" => "images/ads/toyota.png"
    ],
    [
        "title" => "IBM",
        "url" => "https://www.ibm.com",
        "thumbnail_url" => "images/ads/ibm.png"
    ],
    [
        "title" => "Samsung",
        "url" => "https://www.samsung.com",
        "thumbnail_url" => "images/ads/samsung.png"
    ],
    [
        "title" => "Amazon",
        "url" => "https://www.amazon.com",
        "thumbnail_url" => "images/ads/amazon.png"
    ],
    [
        "title" => "Mercedes-Benz",
        "url" => "https://www.mercedes-benz.com",
        "thumbnail_url" => "images/ads/MercedesBenz.png"
    ],
    [
        "title" => "BMW",
        "url" => "https://www.bmw.com",
        "thumbnail_url" => "images/ads/bmw.jpg"
    ],
    [
        "title" => "Sony",
        "url" => "https://www.sony.com",
        "thumbnail_url" => "images/ads/sony.png"
    ],
    [
        "title" => "Youtube",
        "url" => "https://www.youtube.com",
        "thumbnail_url" => "images/ads/youtube.png"
    ],
    [
        "title" => "Visa",
        "url" => "https://www.visa.com",
        "thumbnail_url" => "images/ads/visa.png"
    ],
    [
        "title" => "Nokia",
        "url" => "https://www.nokia.com",
        "thumbnail_url" => "images/ads/nokia.png"
    ],
    [
        "title" => "Cisco",
        "url" => "https://www.cisco.com",
        "thumbnail_url" => "images/ads/cisco.png"
    ],
    [
        "title" => "Dell",
        "url" => "https://www.dell.com",
        "thumbnail_url" => "images/ads/dell.png"
    ],
    [
        "title" => "Lenovo",
        "url" => "https://www.lenovo.com",
        "thumbnail_url" => "images/ads/lenovo.png"
    ],
    [
        "title" => "Acer",
        "url" => "https://www.acer.com",
        "thumbnail_url" => "images/ads/acer.png"
    ],
    [
        "title" => "Canon",
        "url" => "https://www.canon.com",
        "thumbnail_url" => "images/ads/canon.png"
    ],
    [
        "title" => "Intel",
        "url" => "https://www.intel.com",
        "thumbnail_url" => "images/ads/intel.png"
    ],
    [
        "title" => "Lg",
        "url" => "https://www.lg.com",
        "thumbnail_url" => "images/ads/lg.png"
    ],
    [
        "title" => "Nvidia",
        "url" => "https://www.nvidia.com",
        "thumbnail_url" => "images/ads/nvidia.png"
    ],
    [
        "title" => "Pepsi",
        "url" => "https://www.pepsi.com",
        "thumbnail_url" => "images/ads/pepsi.png"
    ],
    [
        "title" => "Asus",
        "url" => "https://www.asus.com",
        "thumbnail_url" => "images/ads/asus.png"
    ],
    [
        "title" => "Durex",
        "url" => "https://www.durex.com",
        "thumbnail_url" => "images/ads/durex.png"
    ],
    [
        "title" => "Konami",
        "url" => "https://www.konami.com",
        "thumbnail_url" => "images/ads/konami.png"
    ],
    [
        "title" => "Logitech",
        "url" => "https://www.logitech.com",
        "thumbnail_url" => "images/ads/logitech.png"
    ],
    [
        "title" => "Oracle",
        "url" => "https://www.oracle.com",
        "thumbnail_url" => "images/ads/oracle.png"
    ],
    [
        "title" => "Skype",
        "url" => "https://www.skype.com",
        "thumbnail_url" => "images/ads/skype.png"
    ]
];
