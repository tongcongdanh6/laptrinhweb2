<?php    
    include('views/blocks/header.php');
?>


<?php
    include('views/pages/cv.php');
?>

<?php
    include('views/blocks/footer.php');
?>