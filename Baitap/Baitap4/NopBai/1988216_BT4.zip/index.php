<?php
    include('views/blocks/header.php');
?>


<?php
    include('views/pages/home.php');
?>

<?php
    include('views/blocks/contact.php');
    include('views/blocks/about.php');
    include('views/blocks/footer.php');
?>