<?php    
    include('views/blocks/header.php');
?>


<?php
    include('views/pages/ads.php');
?>

<?php
    include('views/blocks/contact.php');
    include('views/blocks/footer.php');
?>